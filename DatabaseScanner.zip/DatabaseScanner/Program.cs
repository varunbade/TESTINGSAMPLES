using System;
using System.IO;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Change this to the path of your .NET application that you want to scan
        string projectPath = @"C:\Path\To\Your\Application";  
        
        // File to store the extracted database artifacts
        string outputFile = "DatabaseArtifacts.txt"; 

        Console.WriteLine("Scanning for database artifacts...\n");

        // Get all C# files in the project directory
        string[] files = Directory.GetFiles(projectPath, "*.cs", SearchOption.AllDirectories);

        using (StreamWriter writer = new StreamWriter(outputFile))
        {
            writer.WriteLine("Database Artifacts Found:\n");

            foreach (string file in files)
            {
                string content = File.ReadAllText(file);

                // Find Entity Framework DbSet<> mappings (Tables)
                MatchCollection dbSets = Regex.Matches(content, @"DbSet<(\w+)>");
                foreach (Match match in dbSets)
                {
                    string tableName = match.Groups[1].Value;
                    writer.WriteLine($"[Table] {tableName}");
                    Console.WriteLine($"[Table] {tableName}");
                }

                // Find SQL Queries (SELECT, INSERT, UPDATE, DELETE)
                MatchCollection sqlQueries = Regex.Matches(content, @"\""(SELECT|INSERT|UPDATE|DELETE).*?\""", RegexOptions.IgnoreCase);
                foreach (Match match in sqlQueries)
                {
                    writer.WriteLine($"[SQL Query] {match.Value}");
                    Console.WriteLine($"[SQL Query] {match.Value}");
                }

                // Find Stored Procedure Calls (EXEC or ExecuteSqlRaw)
                MatchCollection storedProcs = Regex.Matches(content, @"(EXEC\s+\w+|ExecuteSqlRaw\(\s*\""(.*?)\""\))", RegexOptions.IgnoreCase);
                foreach (Match match in storedProcs)
                {
                    writer.WriteLine($"[Stored Procedure] {match.Value}");
                    Console.WriteLine($"[Stored Procedure] {match.Value}");
                }
            }
        }

        Console.WriteLine($"\nScanning complete. Results saved to {outputFile}");
    }
}
