# DatabaseScanner

## Description
This is a .NET Console Application that scans a .NET project for database-related artifacts such as:
- Tables (`DbSet<>` in Entity Framework)
- Raw SQL queries (`SELECT`, `INSERT`, `UPDATE`, `DELETE`)
- Stored procedure calls (`EXEC`, `ExecuteSqlRaw`)

## How to Use
1. **Clone or Download the repository** from Bitbucket.
2. Open the `DatabaseScanner.sln` solution in **Visual Studio**.
3. **Update the `projectPath`** in `Program.cs` to point to your application's directory.
4. Run the application in **Debug mode (F5)** or **Release mode (Ctrl + F5)**.
5. The results will be saved in **DatabaseArtifacts.txt**.

## Output Example
```
[Table] Customers
[Table] Orders
[SQL Query] "SELECT * FROM Customers WHERE CustomerId = @id"
[Stored Procedure] EXEC GetCustomerOrders
```
